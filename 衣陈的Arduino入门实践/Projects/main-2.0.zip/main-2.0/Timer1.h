void Timer1_setup(int px);
extern void (*callback) ();
ISR(TIMER1_COMPA_vect);
void Timeroff();
void Timer1on();