#define N 4
typedef unsigned long u32;
extern const char key[N][N];
extern const int row[N];
extern const int col[N];


void key_setup();
void keyscan();